#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Dec 10 15:05:22 2019

@author: ubiquitous
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import numpy as np
import pandas as pd
import sys
from sklearn.metrics import classification_report
import tensorflow as tf
from keras.models import Sequential
from keras.layers import Dense, Input, LSTM, Reshape
from keras.layers import Dropout, GRU
from keras.layers import Flatten, TimeDistributed
from keras.layers.convolutional import Convolution2D
from keras.layers.convolutional import MaxPooling2D
from keras.utils import np_utils
from keras.models import Model
from keras.layers import concatenate
from keras import backend as K
from keract import get_activations,display_activations, persist_to_json_file
K.set_image_dim_ordering( 'th' )
import warnings
warnings.filterwarnings("ignore")
from warnings import simplefilter
simplefilter(action='ignore', category=FutureWarning)
seed = 7
np.random.seed(seed)
import timeit
start = timeit.default_timer()

###########################for different epochs##########################
def main_model(e1):
	INPUT_SIGNAL_TYPES1 = [
	"Acc_x",
	"Acc_y",
	"Acc_z",
	]

	INPUT_SIGNAL_TYPES2 = [
	"Gyr_x",
	"Gyr_y",
	"Gyr_z",
	]

	INPUT_SIGNAL_TYPES3 = [
	"Mag_x",
	"Mag_y",
	"Mag_z",
	]

	INPUT_SIGNAL_TYPES4 = [
	"LAcc_x",
	"LAcc_y",
	"LAcc_z",
	]

	INPUT_SIGNAL_TYPES5 = [
	"Ori_w",
	"Ori_x",
	"Ori_y",
	"Ori_z",
	]


	########################F1-score,precision,recall############################
	def recall_m(y_true, y_pred):
            true_positives = K.sum(K.round(K.clip(y_true * y_pred, 0, 1)))
            possible_positives = K.sum(K.round(K.clip(y_true, 0, 1)))
            recall = true_positives / (possible_positives + K.epsilon())
            return recall

	def precision_m(y_true, y_pred):
        	true_positives = K.sum(K.round(K.clip(y_true * y_pred, 0, 1)))
        	predicted_positives = K.sum(K.round(K.clip(y_pred, 0, 1)))
        	precision = true_positives / (predicted_positives + K.epsilon())
        	return precision

	def f1_m(y_true, y_pred):
        	precision = precision_m(y_true, y_pred)
        	recall = recall_m(y_true, y_pred)
        	return 2*((precision*recall)/(precision+recall+K.epsilon()))

	#####################################################################

	""" PREPARING DATASET FOR DEEP NETWORK """
	TRAIN = "train/"
	TEST = "test/"

	def load_X(X_signals_paths):
            X_signals = []
            for signal_type_path in X_signals_paths:
                file = open(signal_type_path, 'r')
                X_signals.append(
        	    [np.array(serie, dtype=np.float32) for serie in [
        		row.replace('  ', ' ').strip().split(' ') for row in file
        	    ]]
        	) 
            file.close()
            return np.transpose(np.array(X_signals), (1, 2, 0))

	X_train_signals_paths = [
	TRAIN + signal + ".txt" for signal in INPUT_SIGNAL_TYPES1
	]
	X_test_signals_paths = [
	TEST + signal + ".txt" for signal in INPUT_SIGNAL_TYPES1
	]

	X_train1 = load_X(X_train_signals_paths)
	X_test1 = load_X(X_test_signals_paths)

	X_train_signals_paths = [
	TRAIN + signal + ".txt" for signal in INPUT_SIGNAL_TYPES2
	]
	X_test_signals_paths = [
	TEST + signal + ".txt" for signal in INPUT_SIGNAL_TYPES2
	]
	X_train2 = load_X(X_train_signals_paths)
	X_test2 = load_X(X_test_signals_paths)


	X_train_signals_paths = [
	TRAIN + signal + ".txt" for signal in INPUT_SIGNAL_TYPES3
	]
	X_test_signals_paths = [
	TEST + signal + ".txt" for signal in INPUT_SIGNAL_TYPES3
	]
	X_train3 = load_X(X_train_signals_paths)
	X_test3 = load_X(X_test_signals_paths)

	X_train_signals_paths = [
	TRAIN + signal + ".txt" for signal in INPUT_SIGNAL_TYPES4
	]
	X_test_signals_paths = [
	TEST + signal + ".txt" for signal in INPUT_SIGNAL_TYPES4
	]
	X_train4 = load_X(X_train_signals_paths)
	X_test4 = load_X(X_test_signals_paths)

	X_train_signals_paths = [
	TRAIN + signal + ".txt" for signal in INPUT_SIGNAL_TYPES5
	]
	X_test_signals_paths = [
	TEST + signal + ".txt" for signal in INPUT_SIGNAL_TYPES5
	]
	X_train5 = load_X(X_train_signals_paths)
	X_test5 = load_X(X_test_signals_paths)
    
	def load_y(y_path):
	    file = open(y_path, 'r')
	    y_ = np.array(
		[elem for elem in [
		    row.replace('  ', ' ').strip().split(' ') for row in file
		]], 
		dtype=np.int32
	    )
	    file.close()
	    return y_ - 1
	y_train_path =  TRAIN + "y_train.txt"
	y_test_path =  TEST + "y_test.txt"

	y_train = load_y(y_train_path)
	y_test = load_y(y_test_path)


	##################resize and channelizing the input########################
	X_train1 = X_train1.reshape(X_train1.shape[0],3, 1, 300).astype( 'float32' )
	X_test1 = X_test1.reshape(X_test1.shape[0], 3, 1, 300).astype( 'float32' )
	X_train2 = X_train2.reshape(X_train2.shape[0],3, 1, 300).astype( 'float32')
	X_test2 = X_test2.reshape(X_test2.shape[0], 3, 1, 300).astype( 'float32')
	X_train3 = X_train3.reshape(X_train3.shape[0],3, 1, 300).astype( 'float32')
	X_test3 = X_test3.reshape(X_test3.shape[0], 3, 1, 300).astype( 'float32')
	X_train4 = X_train4.reshape(X_train4.shape[0],3, 1, 300).astype( 'float32')
	X_test4 = X_test4.reshape(X_test4.shape[0], 3, 1, 300).astype( 'float32' )
	X_train5 = X_train5.reshape(X_train5.shape[0],4, 1, 300).astype( 'float32')
	X_test5 = X_test5.reshape(X_test5.shape[0], 4, 1, 300).astype( 'float32' )
	y1=y_test
	y=y_train
	y_train = np_utils.to_categorical(y_train)
	y_test = np_utils.to_categorical(y_test)
	num_classes = y_test.shape[1]
        ##############################CNN model#####################################
	def baseline_model():
        	model_in = Input(shape=(3, 1, 300))
        	l_2=(Convolution2D(128, 1, 1, activation= 'relu' ))(model_in)   
        	l_3=(Convolution2D(64, 1, 1, activation= 'relu' ))(l_2)   
        	l_5=(Flatten())(l_3)
        	model_out = Dense(64, activation='relu')(l_5)
        	return model_in, model_out 
	m11,m12 = baseline_model()
	model1 = Model(m11,m12)
	m21,m22 = baseline_model()
	model2 =Model(m21,m22)
	m31,m32 = baseline_model()
	model3 =Model(m31,m32)
	m41,m42 = baseline_model()
	model4 =Model(m41,m42)
	#print("Adding model 5")
	def baseline_model():
        	model_in = Input(shape=(4, 1, 300))
        	l_2=(Convolution2D(128, 1, 1, activation= 'relu' ))(model_in)   
        	l_3=(Convolution2D(64, 1, 1, activation= 'sigmoid' ))(l_2)   
        	l_5=(Flatten())(l_3)
        	model_out = Dense(64, activation='relu')(l_5)
        	return model_in, model_out 
	m51,m52 = baseline_model()
	model5 =Model(m51,m52)
	################Towrads LSTM###############################################
	concatenated = concatenate([m12, m22, m32, m42,m52])
	out1 = (Dense(64, activation='relu', name ="e1" ))(concatenated)
	out1=(Reshape((-1,64), input_shape=(-1,64)))(out1)
	out2=(LSTM(64, activation= 'relu', return_sequences=True))(out1) 
	out3=(LSTM(32, activation= 'relu',name ="e" ))(out2) 
	out4=(Dense(8, activation='softmax'))(out3)
	################Merged model#########################################################################################
	merged_model = Model([m11, m21, m31,m41,m51], out4)
	merged_model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=[f1_m,precision_m, recall_m])
	merged_model.fit([X_train1, X_train2, X_train3, X_train4, X_train5], y=y_train, batch_size=200, epochs=e1,verbose=0)
	stop = timeit.default_timer()
	start = timeit.default_timer()
	scores = merged_model.evaluate([X_test1, X_test2, X_test3, X_test4, X_test5], y_test, verbose=0)
	#print("CNN Error: %.2f%%" % (100-scores[1]*100))
	stop = timeit.default_timer()

	y_pred = merged_model.predict([X_test1, X_test2, X_test3, X_test4, X_test5], batch_size=64, verbose=2)
	y_pred_e = np.argmax(y_pred, axis=1)
	#print(classification_report(y1, y_pred_e))
	return classification_report(y1, y_pred_e)
##########################input arguments####################################################################################
argumentList = sys.argv
#for i in range(len(sys.argv)-1): 
e1=int(sys.argv[1])
p=main_model(e1)
print("Confusion matrix with:"+str(e1)+ "epochs")
print(p)

