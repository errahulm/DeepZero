#!/usr/bin/env bash
echo "Seen class accuracy on different epochs"
python main_model_report.py 5 > results_5_epochs.txt
echo "5 epochs Complete"
python main_model_report.py 10 > results_10_epochs.txt
echo "10 epochs Complete"
python main_model_report.py 15 > results_15_epochs.txt
echo "15 epochs Complete"
python main_model_report.py 20 > results_20_epochs.txt
echo "20 epochs Complete"
python main_model_report.py 25 > results_25_epochs.txt
echo "25 epochs Complete"
python main_model_report.py 30 > results_30_epochs.txt
echo "30 epochs Complete"
python main_model_report.py 35 > results_35_epochs.txt
echo "35 epochs Complete"
python main_model_report.py 40 > results_40_epochs.txt
echo "40 epochs Complete"
python main_model_report.py 45 > results_45_epochs.txt
echo "45 epochs Complete"
python main_model_report.py 50 > results_50_epochs.txt
echo "50 epochs Complete"


