# -*- coding: utf-8 -*-
"""
Created on Sun Feb 25 23:41:38 2018

@author: RAHUL
"""

from gensim.scripts.glove2word2vec import glove2word2vec
from gensim.models import KeyedVectors
import numpy as np
from sklearn.decomposition import PCA
from matplotlib import pyplot
import pandas as pd
import warnings
warnings.filterwarnings("ignore")

#%%

glove_path = 'GloVe/glove.6B.300d.txt'
w2v_path =   'GloVe/glove.6B.300d.txt.word2vec'
glove2word2vec(glove_path, w2v_path)

#%%


model = KeyedVectors.load_word2vec_format(w2v_path, binary = False)
"""
results = model.most_similar(positive = ['woman', 'king'], negative = ['man'], topn = 3)
print (results)

"""
words = list (model.vocab)
#print (words)



#%%

X = model[model.vocab]  # 400000 * 50
print (X.shape)







aam = pd.DataFrame()
#CLASS0  =  Still
c0=  model['still']

c0 = pd.DataFrame(c0)             # data frame = 50 * 1
c0 = pd.DataFrame.transpose(c0)   # data frame = 1 * 50

aam = aam.append(c0, ignore_index = True)  # data frame = 1 * 50
#print (aam.shape)





# CLASS 1 = Walk
d1 = model['walk']

#d=(0.7*d1-0.3*d2)/1
d = pd.DataFrame(d1)
d = pd.DataFrame.transpose(d)

aam = aam.append(d, ignore_index  = True)
#print (aam.shape)





# CLASS 2= Run
d = model['run']

d = pd.DataFrame(d)
d = pd.DataFrame.transpose(d)

aam = aam.append(d, ignore_index  = True)
#print (aam.shape)




# CLASS 3 =Bike
d = model['bike']

d = pd.DataFrame(d)
d = pd.DataFrame.transpose(d)

aam = aam.append(d, ignore_index  = True)
#print (aam.shape)




# CLASS 4=Car
d = model['car']

d = pd.DataFrame(d)
d = pd.DataFrame.transpose(d)

aam = aam.append(d, ignore_index  = True)
#print (aam.shape) 


# CLASS 5= Bus
d = model['bus']

d = pd.DataFrame(d)
d = pd.DataFrame.transpose(d)

aam = aam.append(d, ignore_index  = True)
#print (aam.shape)





# CLASS 6 =Train
d = model['train']

d = pd.DataFrame(d)
d = pd.DataFrame.transpose(d)

aam = aam.append(d, ignore_index  = True)
#print (aam.shape)






# CLASS 7= Subway
d = model['subway']
#d1=model['sit']
print ('subway' in words)

#d=(d+d1)/2
d = pd.DataFrame(d)
d = pd.DataFrame.transpose(d)

aam = aam.append(d, ignore_index  = True)
print (aam.shape)


class_names = ['still', 'walk', 'run', 'bike', 'car', 'bus', 'train', 'subway']


pca = PCA(n_components = 2)
results = pca.fit_transform(aam)

pyplot.figure(figsize = (10, 10))
pyplot.scatter(results[:, 0], results[:, 1], marker = 'o')

for i, word in enumerate(class_names):
    pyplot.annotate(word, xy = (results[i, 0], results[i, 1]) )
pyplot.show


aam = aam.T
print (aam.shape)
aam.to_csv('activity_attribute_matrix_not_probability300.csv', header = class_names, index = None)

#%% LOAD DATA

df = pd.read_csv('activity_attribute_matrix_not_probability300.csv')
print (df.shape) # n_att * n_cls

#%% CONVERT DATAFRAME TO NUMPY ARRAY

z = np.array(df) # n_att * n_cls
print (z.shape)
#re = z[:, 11].reshape(14, 1)
#print (re.shape) # 1n_att * n_cls


#%%
def softmax(x):
    # Calculates the softmax for each row of the input x.
    # Argument: x -- A numpy matrix of shape (n_att, n_cls)

    # Returns: s -- A numpy matrix equal to the softmax of x, of shape (n_att, n_cls)
    
    

    # Apply exp() element-wise to x. 
    x_exp = np.exp(x)
    # Create a vector x_sum that sums each column of x_exp.
    x_sum = x_exp.sum(axis = 0, keepdims = True)
    print (x_sum.shape) # 1 * n_cls
    
    # Compute softmax(x) by dividing x_exp by x_sum. It should automatically use numpy broadcasting.
    s = x_exp / x_sum
    print(s.shape) # n_att * n_cls
    
    
    return s


#%%

aam_p = softmax(z) # n_att * n_cls .  SUM ALONG COLUMNS IS 1
print (aam_p.shape) 

x_sum = aam_p.sum(axis = 0, keepdims = True)
print (x_sum, x_sum.shape) 


#%% SAVE ATTRIBUTE MATRIX  PROBABILITY IN CSV FILE

aam_p_df = pd.DataFrame(aam_p) 
aam_p_df.to_csv('activity_attribute_matrix300.csv', header = class_names, index = None)


#%% LOAD

df = pd.read_csv('activity_attribute_matrix300.csv')
print (df, df.shape)


